package com.nhandz.flrv_ch.DT;

public interface SendIDBV {
    public void GetID(String IDBV);
}
